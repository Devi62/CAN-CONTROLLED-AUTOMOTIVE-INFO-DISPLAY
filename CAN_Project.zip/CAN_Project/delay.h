#include"type.h"
void delay_us(u32 dlyUS);
void delay_ms(u32 dlyMS);
void delay_s(u32 dlYS);
