#include<LPC21XX.h>
#include"type.h"
#include"rtc.h"
#include"pin_connect_block.h"
#include"delay.h"
#include"lcd__defines.h"
#include"lcd.h"
#include"external_interrupt.h"
#include"ds18b20.h"
#include"can.h"
#include"can_defines.h"
#define sw1 16
#define sw2 14
u32 flag1=0,flag2=0;
char cgram_lut[] = {0x0e,0x11,0x11,0x11,0x11,0x11,0x11,0x1f};
struct CAN_Frame txFrame;
struct CAN_Frame rxFrame;
main()
{
u32 temp;
u8 tp,tpd;
s32 hour,min,sec;
Initlcd();//intialize lcd
Init_CAN1();//intialize CAN
RTC_Init();//intialize RTC

enable_EINT0();//enabling external interrupt EINT0
enable_EINT1();//enabling external interrupt EINT1

cmdlcd(GOTO_LINE1_POS0);
strlcd("DS18B20 Interface:");
delay_ms(2000);
while(1)
{
temp=ReadTemp();//READING TEMPERATURE FROM DS18B20 USING 1-WIRE PROTOCOL
tp=temp>>4;//GETTING INTEGER PART
tpd=temp&0x08?0x35:0x30;//GETTING FRACTIONAL PART        
cmdlcd(GOTO_LINE2_POS0);//Displaying temp on lcd
strlcd("Temp=");
cmdlcd(0xC0+5);
S32lcd(tp);
cmdlcd(0xC0+7);
charlcd('.');
cmdlcd(0xC0+8);
charlcd(tpd);
charlcd(223);
cmdlcd(0xC0+9);
strlcd("C");
GetRTCTime(&hour,&min,&sec);
DisplayRTCTime(hour,min,sec);//Displaying RTC time	 */
if(flag1==1)
{
/*txFrame.ID=1 ;
txFrame.vbf.DLC=8 ;
txFrame.Data1='L';
txFrame.Data2=0x00;	*/
CAN1_Tx(txFrame);
}
else if(flag2==1)
{
CAN1_Tx(txFrame);
}
if((C1GSR&RBS_BIT_READ))
{
	CAN1_Rx(&rxFrame);	  //receiveing fuel information
	if(rxFrame.ID==2)
	{
		cmdlcd(GOTO_LINE4_POS0);
		strlcd("fuel:");
		U32lcd(rxFrame.Data1);
		strlcd("%");
		delay_ms(500);
		cmdlcd(GOTO_LINE4_POS0+5);
		strlcd("   ");
		//cmdlcd(0x01);
	}
}
}
}
   


