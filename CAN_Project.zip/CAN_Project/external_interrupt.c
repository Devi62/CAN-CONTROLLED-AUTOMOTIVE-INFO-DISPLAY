#include<LPC21XX.h>								  
#include"type.h"
#include"delay.h"
#include"external_interrupt.h"
#include"lcd.h"
#include"lcd_defines.h"
#include"pin_connect_block.h"
#include"can.h"
#include"can_defines.h"
#define eint1_vic_ch0 15
#define eint0_vic_ch0 14
u32 count=0,count1=0;
extern u32 flag1;
extern u32 flag2;
extern struct CAN_Frame txFrame;
void eint0_isr(void) __irq
{
++count;
if(count==1)
{
txFrame.ID=1 ;
txFrame.vbf.DLC=8 ;
txFrame.Data1='L';
txFrame.Data2=0x00;
flag1=1;
cmdlcd(0x94);
strlcd("EINT0");
cmdlcd(0x94+6);
strlcd("<-");
delay_ms(500);
}
else if(count==2)
{
txFrame.ID=1 ;
txFrame.vbf.DLC=8 ;
txFrame.Data1='L';
txFrame.Data2=0xff;
count=0;
flag1=1;
cmdlcd(0x94);
strlcd("                      ");
}
//CAN1_Tx(txFrame);
/*cmdlcd(0x94);
strlcd("EINT0");
cmdlcd(0x94+6);
strlcd("<-");
delay_ms(500); */
EXTINT=1<<0;
VICVectAddr=0;
}

void eint1_isr(void) __irq
{
++count1;
if(count1==1)
{
txFrame.ID=1 ;
txFrame.vbf.DLC=8 ;
txFrame.Data1='R';
txFrame.Data2=0x00;
flag2=1;
cmdlcd(0x94);
strlcd("                      ");
cmdlcd(0x94+9);
strlcd("EINT1");
cmdlcd(0x94+15);
strlcd("->");
delay_ms(500);
}
else if(count1==2)
{
txFrame.ID=1 ;
txFrame.vbf.DLC=8 ;
txFrame.Data1='R';
txFrame.Data2=0xff;
count1=0;
flag2=1;
cmdlcd(0x94);
strlcd("                      ");
}
//CAN1_Tx(txFrame);
/*cmdlcd(0x94+9);
strlcd("EINT1");
cmdlcd(0x94+15);
strlcd("->");
delay_ms(500);*/
EXTINT=1<<1;
VICVectAddr=0;
}
void enable_EINT0(void)
{
CfgPortPinFunc(0,16,1);
VICIntEnable|=1<<eint0_vic_ch0;
VICVectCntl0=(1<<5)|eint0_vic_ch0;
VICVectAddr0=(u32)eint0_isr;
//enable EINT0 via ext int blk
//EXTINT=0;
EXTMODE|=1<<0;
//cnf eint0 for raising edge
//EXTPOLAR=1<<0;
}

void enable_EINT1(void)
{
CfgPortPinFunc(0,14,2);
VICIntEnable|=1<<eint1_vic_ch0;
VICVectCntl1=(1<<5)|eint1_vic_ch0;
VICVectAddr1=(u32)eint1_isr;
//enable EINT1 via ext int blk
//EXTINT=0;
EXTMODE|=1<<1;
//cnf eint1 for raising edge
//EXTPOLAR=1<<1;
}

