#include<lpc21xx.h>
#include"can.h"
#include"can_defines.h"
#include"adc.h"
#include"adc_defines.h"
#include"type.h"
#include"delay.h"
#include "lcd.h"
float ar;
int fuel;
int main()
{
    struct CAN_Frame txFrame;
	//Initlcd();
	Init_ADC();
	Init_CAN1();
	txFrame.ID=2;
	txFrame.vbf.RTR=0;
	while(1)
	{
	ar=Read_ADC(1);
	//cmdlcd(0x80);
	//F32lcd(ar,2);
	//strlcd("fuel: ");
	fuel=((ar-0.27)/(1.80-0.27))*100;
	if(fuel<=0)
	{
		fuel=0;
	}
	else if(fuel>99)
	{
		fuel=99;
	}
	txFrame.Data1=fuel;
	txFrame.vbf.DLC=4;
	CAN1_Tx(txFrame);
	delay_ms(500);
	}
}

	 
   

