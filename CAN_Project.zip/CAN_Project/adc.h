#ifndef _ADC_H_

#define _ADC_H_


#include "type.h"

void Init_ADC(void);

f32 Read_ADC(u8 chNo);


#endif
